function edit()
{
    var id = event.target.id
   console.log(event.target.id);
     fetch('http://localhost:5250/api/Product/'+id, {
     })
     .then((response) => response.json())
     .then((json) => {
        
          console.log(json.patientDepartment)
          console.log(json.patientDiagnosis)
          var diagnosis = document.getElementById("diagnosis")
          var department = document.getElementById("department")
          var id = document.getElementById("id")
         
          diagnosis.value=json.patientDiagnosis
          department.value=json.patientDepartment
          id.setAttribute("value",json.patientId)
          
     }
     )
};
function editAddTreatment()
{
    var ids = event.target.id
    var id = document.getElementById("id")
    id.setAttribute("value",json.treatmentId)
   
};
function editTreatment()
{
    var id = event.target.id
   console.log(event.target.id);
   console.log("hello world")
     fetch('http://localhost:5250/GetPatientTreatment/'+id, {
     })
     .then((response) => response.json())
     .then((json) => {
        var treatment = document.getElementById("treatment")
        var id = document.getElementById("id")
        console.log("patient treatment"+json.patientTreatment);
        treatment.value=json.patientTreatment
        id.setAttribute("value",json.treatmentId)
          
     }
     )
};
function editAddTreatment()
{
    var ids = event.target.id
    var id = document.getElementById("id")
    id.setAttribute("value",ids)
    console.log(event.target.id);
};
function saveTreatment()
{

    var treatment = document.getElementById("treatment").value
    console.log(treatment);
    var id = document.getElementById("id").value
    form ={
        patientId:0,
        dateTime:'2023-12-22T13:52:07.313Z',
        patientTreatment:treatment,
        treatmentId:id
    }
    fetch('http://localhost:5250/EditPatientTreatment', {
        method: 'POST',
        body: JSON.stringify(form),
        headers:{'content-type': 'application/json'},
        })
        .then((response) => response.json())
        .then((json) => {
            var treatment = document.getElementById("treatment"+id)
          
          console.log(treatment)
          treatment.textContent = json.patientTreatment;
          alert('saved')
            console.log(json)  
        }
        )
}
function saveAddTreatment()
{

    var treatment = document.getElementById("treatment").value
    console.log(treatment);
    var id = document.getElementById("id").value
    const d = new Date();
    let date = d.toISOString(); 
    form ={
        patientId:id,
        dateTime:date,
        patientTreatment:treatment
    }
    fetch('http://localhost:5250/AddPatientTreatment', {
        method: 'POST',
        body: JSON.stringify(form),
        headers:{'content-type': 'application/json'},
        })
        .then((response) => response.json())
        .then((json) => {
          
          alert('saved')
            console.log(json)  
        }
        )
}
function save()
{

    var diagnosis = document.getElementById("diagnosis").value
    var department = document.getElementById("department").value
    var id = document.getElementById("id").value
    form ={
        patientId:id,
        patientDepartment:department,
        patientDiagnosis:diagnosis,
        patientName:'empty',
        patientSurname:'empty',
        patientAge:'12'
    }
    fetch('http://localhost:5250/api/Product/EditPatient', {
        method: 'POST',
        body: JSON.stringify(form),
        headers:{'content-type': 'application/json'},
        })
        .then((response) => response.json())
        .then((json) => {
            var diagnosis = document.getElementById("diagnosis"+id)
          var department = document.getElementById("department"+id)
          console.log(diagnosis)
          console.log(department)
          diagnosis.textContent = json.patientDiagnosis;
          department.textContent =json.patientDepartment
          alert('saved')
            console.log(json)  
        }
        )
}

let myForm = document.getElementById('myForm')

myForm.addEventListener('submit', function(e){
  e.preventDefault()  
  let firstName = this.querySelector('#search').value
  
  fetch('http://localhost:5250/SearchPatient/'+firstName, {
        })
            .then((response) => response.json())
            .then((json) => {
                var records = document.getElementById('records')
                records.innerHTML="";
                console.log(json[0].patientName)
            for (var i = 0; i < json.length; i++) 
            { 
                var row = document.createElement("tr"); 
 
                var idCell = document.createElement("td"); 
                idCell.textContent = i; 
                row.appendChild(idCell); 

                var nameCell = document.createElement("td"); 
                nameCell.textContent = json[i].patientName; 
                row.appendChild(nameCell); 

                var surnameCell = document.createElement("td"); 
                surnameCell.textContent = json[i].patientSurname; 
                row.appendChild(surnameCell); 

                var diagnosisCell = document.createElement("td"); 
                diagnosisCell.textContent = json[i].patientDiagnosis; 
                var diatext = "diagnosis"
                var count = i+1
                diagnosisCell.setAttribute("id",diatext+count)
                row.appendChild(diagnosisCell); 
                
                var ageCell = document.createElement("td"); 
                ageCell.textContent = json[i].patientAge; 
                row.appendChild(ageCell); 
               
                var departmentCell = document.createElement("td"); 
                departmentCell.textContent = json[i].patientDepartment; 
                var deptext = "department"
                var count = i+1
                departmentCell.setAttribute("id",json[i].patientId)
                row.appendChild(departmentCell); 
               
                var detailsCell = document.createElement("td");
                var button = document.createElement("button");
                button.setAttribute("class","btn btn-danger")
                button.setAttribute("id",json[i].patientId)
                button.setAttribute("data-toggle","modal")
                button.setAttribute("data-target","#exampleModal")
                button.setAttribute("onClick","edit()")
                button.textContent = "Edit"
                detailsCell.appendChild(button)
                var detailsCell1 = document.createElement("td");
                var button1 = document.createElement("button");
                button1.setAttribute("class","btn btn-primary btn1")
                button1.setAttribute("id",json[i].patientId)
                button1.setAttribute("data-toggle","modal")
                button1.setAttribute("data-target","#exampleModal1")
                button1.setAttribute("onClick","editAddTreatment()")
                button1.textContent = "Add diagnosis"

                detailsCell.appendChild(button)
                detailsCell1.appendChild(button1)
                row.appendChild(detailsCell); 
                row.appendChild(detailsCell1);

                records.appendChild(row); 
                } 
            });
        
})